
  # Imposter Game Implementation Spec

  This is a code bundle for Imposter Game Implementation Spec. The original project is available at https://www.figma.com/design/Xkd30MAugaH8ieBecUlJwX/Imposter-Game-Implementation-Spec.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  